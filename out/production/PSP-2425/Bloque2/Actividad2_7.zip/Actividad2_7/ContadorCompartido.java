package Bloque2.Actividad2_7;

public class ContadorCompartido {
    /* Clase que hace la funcion de contador. Tiene un método para incrementarlo y uno para devolver su valor */
    private int valor = 0;

    public int getValor() {
        return valor;
    }

    public void incrementar() {
        valor++;
    }
}
